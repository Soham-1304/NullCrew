import { NextResponse } from "next/server";

export async function POST(req: Request) {
  try {
    if (!process.env.LANGFLOW_API_URL || !process.env.LANGFLOW_API_KEY) {
      return NextResponse.json(
        { error: "Missing Langflow configuration" },
        { status: 500 }
      );
    }

    const body = await req.json();
    const { message, history } = body;

    if (!message || !Array.isArray(history)) {
      return NextResponse.json(
        { error: "Invalid request body: 'message' must be a string and 'history' must be an array" },
        { status: 400 }
      );
    }

    const chatHistory = history.map((msg: any) => ({
      content: msg.content,
      type: msg.role === "user" ? "human" : "assistant",
    }));

    console.log("Sending request to Langflow:", {
      url: `${process.env.LANGFLOW_API_URL}/predict`,
      message,
      chatHistory,
    });

    const response = await fetch(`${process.env.LANGFLOW_API_URL}/predict`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${process.env.LANGFLOW_API_KEY}`,
      },
      body: JSON.stringify({
        question: message,
        chat_history: chatHistory,
      }),
    });

    const data = await response.json();

    console.log("Received response from Langflow:", data);

    if (!response.ok) {
      return NextResponse.json(
        { error: `Langflow API error: ${response.status} ${response.statusText}`, details: data },
        { status: response.status }
      );
    }

    const aiResponse = data?.response || data?.answer || Object.values(data).find(Boolean);

    if (!aiResponse) {
      return NextResponse.json(
        { error: `No valid response received from Langflow: ${JSON.stringify(data)}` },
        { status: 500 }
      );
    }

    return NextResponse.json({ response: aiResponse });
  } catch (error) {
    console.error("Error in chat API:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Failed to process the request" },
      { status: 500 }
    );
  }
}
