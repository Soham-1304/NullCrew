const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

const API_URL = 'https://api.langflow.astra.datastax.com/lf/fb846b23-539e-4878-a440-5407cbca01c6/api/v1/run/9b75d41e-70f7-4ed6-8aa3-4cc30db63de2';
const API_TOKEN = 'AstraCS:AycJONyUntWZUQjexmvXWjEC:d0f974cafc534fd02e13c0913e7e0c3dcbb65ae16ccd49e349a6df8de5825a0f';

app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;
    console.log('Received message:', message);
    
    // Format the request payload
    const payload = {
      input: {
        question: message
      }
    };
    
    console.log('Sending payload to Langflow:', JSON.stringify(payload, null, 2));

    const response = await axios.post(API_URL, payload, {
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_TOKEN}`
      }
    });

    console.log('Raw API Response:', JSON.stringify(response.data, null, 2));

    // Extract the message from the nested response structure
    let botResponse = null;
    
    if (response.data?.outputs?.[0]?.outputs?.[0]?.messages?.[0]?.message) {
      botResponse = response.data.outputs[0].outputs[0].messages[0].message;
    }
    
    if (!botResponse) {
      console.log('Could not find message in response structure:', response.data);
      botResponse = 'I apologize, but I am unable to process your request at the moment.';
    }

    res.json({ response: botResponse });
  } catch (error) {
    console.error('API Error:', {
      message: error.message,
      response: error.response?.data,
      status: error.response?.status
    });
    
    res.status(500).json({
      error: 'Failed to process your request',
      details: {
        message: error.message,
        status: error.response?.status,
        data: error.response?.data
      }
    });
  }
});

const PORT = 3007;

// Kill any existing process on PORT 3007
const { execSync } = require('child_process');
try {
  execSync(`lsof -ti:${PORT} | xargs kill -9`);
} catch (error) {
  // Ignore errors if no process was found
}

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
  console.log('API URL:', API_URL);
});
